<? if ($view === 'selfrecording'): ?>

<h2>Aufzeichnung im Studio: Das Self-Recording-Studio im LehrKolleg</h2>

<iframe src="https://video4.virtuos.uos.de/paella/ui/embed.html?id=ed679a91-79bd-412e-8aea-5b03ef796ef9" name="Paella Player"  allowfullscreen="" width="570" height="321" frameborder="0"></iframe>


<? endif ?>