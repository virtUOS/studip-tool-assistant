<? if ($view === 'howto'): ?>
    <h2>Simple turning-in procedures: Homework folder</h2>
    <div style="float:right;margin-left:10px;">
        <p>
            <img src="<?= $plugin->getPluginURL() ?>/assets/studip-hausaufgaben-aktionen.jpg" width="240">
        </p>
        <p>
            <img src="<?= $plugin->getPluginURL() ?>/assets/studip-hausaufgaben-typ.jpg" width="240">
        </p>

    </div>
    <p>
        On the "Files" page, click on "New folder" in the navigation bar on the left.
    </p>
    <p>
        Then enter a suitable name for the folder above.
        Further down select "Folder for homework" and confirm with "Create".
    </p>
<? endif ?>
